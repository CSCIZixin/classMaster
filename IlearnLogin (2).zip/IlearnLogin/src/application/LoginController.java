package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;

import application.user.time;

import java.sql.PreparedStatement;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;



public class LoginController {

		@FXML Label notice;
		@FXML TextField UserName;
		@FXML Label helptxt;
		@FXML PasswordField Password;
		public String use, pass, one, two, three;
		
		
		public void login(ActionEvent event) throws Exception{
			PreparedStatement ps;
			try{
				
				Connection conn = DBConnect.getConnection();
				ps = conn.prepareStatement("SELECT `firstname`, `password` ,id FROM `users` WHERE `firstname` =? AND `password` =?");
				ps.setString(1, UserName.getText());
				ps.setString(2, Password.getText());
				ResultSet result = ps.executeQuery();
				if(result.next()){
					 pass = (Password.getText());
					 use = (UserName.getText());
					 ps = conn.prepareStatement("SELECT * FROM `register` WHERE `studentId` =? ");
					 ps.setInt(1, result.getInt("id"));
					 ResultSet myResult = ps.executeQuery();
					 HashMap<String,String> map= new HashMap<String,String>();
					 HashMap<String,String> timeMap= new HashMap<String,String>();
					 HashSet<String> timeList= new  HashSet<String>();
					 while(myResult.next()) {
						 map.put(myResult.getString("CRN"),myResult.getString("courseName"));
						 timeList.add(new time(myResult.getString("time"), myResult.getString("day")).getS());
						 }
					 
					 new user(use,result.getInt("id"),map,timeList);
					 System.out.println(timeList.toString());

					((Node)event.getSource()).getScene().getWindow().hide();

//					FXMLLoader Loader = new FXMLLoader();
//					Loader.setLocation(getClass().getResource("studentView.fxml"));
//					try {
//						Loader.load();
//					} catch (IOException ex){
//						Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
//					}
					Connection con = DBConnect.getConnection();

					String query = ("SELECT CourseOne, CourseTwo, CourseThree FROM users WHERE password = '" + pass +"'");
					Statement stmt = con.createStatement();

				        ResultSet rs = stmt.executeQuery(query);

				        while (rs.next()) {
				           String ONE = rs.getString("CourseOne");
				           String TWO = rs.getString("CourseTwo");
				           String THREE = rs.getString("CourseThree");
						
//
//						try{
//											Parent p = Loader.getRoot();
//											Stage stage = new Stage();
//											stage.setScene(new Scene(p));
//						
//											stage.showAndWait();
//						} catch(Exception e)
//						{
//							e.printStackTrace();
//						}
				           
				            try {
								Parent tableViewParent = FXMLLoader.load(getClass().getResource("studentView.fxml"));
								Scene tableViewScene = new Scene(tableViewParent);
								
								//This line gets the Stage information
								Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
								
								window.setScene(tableViewScene);
								window.show();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								//e.printStackTrace();
							}

		
							
						}
						}
						else{
							notice.setText("Invalid Username or Password");
						}
					     

				
			} catch(SQLException ex){
				DBConnect.displayException(ex);
		


		}
			


}
		public void signUpButtonPushed(ActionEvent event) throws Exception{
			
			FXMLLoader Loader = new FXMLLoader();
			Loader.setLocation(getClass().getResource("signup.fxml"));
			
			try {
				Loader.load();
			} catch (IOException ex){
				Logger.getLogger(HomePageController.class.getName()).log(Level.SEVERE, null, ex);
			}
			try{
					Parent a = Loader.getRoot();
					Stage stage = new Stage();
					stage.setScene(new Scene(a));
		
					stage.showAndWait();
			} catch(Exception e)
			{
			e.printStackTrace();
			}
					
				}



		public void help(){
			helptxt.setText("Enter a Valid Username and Password, For help call 777-777-7777.");

		}
}
