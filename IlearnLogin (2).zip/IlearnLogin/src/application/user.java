package application;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;

public class user {
	public static String username;
	public static int userId;
	public static  HashMap<String,String> hs;
	public static HashMap<String,String>timeTable;
	public static HashSet<String> timeList;
	
	static class time{
		public String getS() {
			return s;
		}
		public void setS(String s) {
			this.s = s;
		}
		public String s="";
		public time(String time,String day) {
			s+=time;
			s+=day;
			
			
		}
		
		
		
	}
	
	
	public static HashMap<String,String> getHs() {
		return hs;
	}


	public static void setHs(HashMap<String,String> hs) {
		user.hs = hs;
	}


	public user(String username,int userId,HashMap<String,String> A,HashSet<String>timeList){
		this.userId=userId;
		this.username=username;
		
		hs= A;
		this.timeList=timeList;
		
		
		
	}


	public static  HashSet<String> getTimeList() {
		return timeList;
	}


	public static void setTimeList( HashSet<String> timeList) {
		user.timeList = timeList;
	}


	public static HashMap<String, String> getTimeTable() {
		return timeTable;
	}


	public static void setTimeTable(HashMap<String, String> timeTable) {
		user.timeTable = timeTable;
	}
	
	
	
	

}
