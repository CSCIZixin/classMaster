package application;

import java.io.IOException;
import application.user.time;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ResourceBundle;

import com.mysql.jdbc.PreparedStatement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ListView.EditEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class classViewController implements Initializable {
	
		@FXML  TableView<course> classTable;
		@FXML  TableColumn col1,col2,col3,col4,col5,capCol,actCol,timeCol,statusCol,dayCol;
		@FXML  ComboBox combobox;
		@FXML  Label la,errorMsg;
		@FXML  Text textBox;
		HashSet<String> haset= new HashSet();
		HashSet<String> time = new  HashSet<String>();
		ObservableList<course> data = FXCollections.observableArrayList() ;	
	@SuppressWarnings("unchecked")
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		combobox.getItems().addAll("Computer Science","English","Mathematics");
		textBox.setText(user.hs.values().toString());
		
	}
	public void setdisable(){
		for(course i:data) {
			if(user.hs.containsKey(i.getCRN())) {
				i.getSelect().setDisable(true);	
			}
	}
	}
	
	
	public void changeSubject(ActionEvent event) {	
		String name = (String) combobox.getSelectionModel().getSelectedItem();
		data.removeAll(data);
	
		try {
			Connection con = DBConnect.getConnection();
			java.sql.PreparedStatement ps;
			ps =con.prepareStatement("SELECT *FROM course where subject =?") ;
			ps.setString( 1,name);
	        ResultSet rs = ps.executeQuery();
	       
	        col1.setCellValueFactory(
	                new PropertyValueFactory<course, String>("CRN"));
	        col2.setCellValueFactory(
	                new PropertyValueFactory<course, String>("courseName"));
	        col3.setCellValueFactory(
	                new PropertyValueFactory<course, String>("courseSection"));
	        timeCol.setCellValueFactory(
	                new PropertyValueFactory<course, String>("time"));
	        capCol.setCellValueFactory(
	                new PropertyValueFactory<course, Integer>("cap"));
	        actCol.setCellValueFactory(
	                new PropertyValueFactory<course, Integer>("act"));
	        col4.setCellValueFactory(
	                new PropertyValueFactory<course, String>("teacher"));
	        col5.setCellValueFactory(
	                new PropertyValueFactory<course, String>("select"));
	        statusCol.setCellValueFactory(
	                new PropertyValueFactory<course, String>("status"));
	        dayCol.setCellValueFactory(
	                new PropertyValueFactory<course, String>("days"));
	        while (rs.next()) {
	           String item1 = rs.getString("CRN"); 
	           String item2 = rs.getString("courseName");
	           String item3 = rs.getString("courseSection");
	           String item4 = rs.getString("teacher");
	           String item5 = rs.getString("time");
	           int cap = rs.getInt("cap");
	           int act = rs.getInt("act");
	           String status = rs.getString("status");
	           String days= rs.getString("day");
	           data.add(new course(item1,item2,item3,item5,days,cap,act,item4,status));
	        }
	        classTable.setItems(data);
	        for(course i:data) {
				if(i.getStatus().equals("close")) {
					i.getSelect().setDisable(true);
					
				}	
			}
		}catch(Exception s) {
		}
	}
	
	
	public void addCheckedItem(ActionEvent event) {
		
		java.sql.PreparedStatement ps,ps2,ps3,ps4,ps5;
		ObservableList<course> ob = FXCollections.observableArrayList();;
		Boolean error=false;
		try {
			Connection conn = DBConnect.getConnection();
			ps = conn.prepareStatement("INSERT INTO `register`(`CRN`, `coursename`, `courseSection`, `StudentId`,time,day) VALUES (?,?,?,?,?,?)");
			ps2 = conn.prepareStatement("UPDATE `course` SET `act`= act+1 WHERE CRN= ?");
			ps3 = conn.prepareStatement("Select * from course where courseName=?");
			ps4 = conn.prepareStatement("UPDATE `course` SET `status`=? WHERE CRN= ?");
			ps3 = conn.prepareStatement("Select * from course where CRN=?");
			
			
			for(course i:data) {
				if(i.getSelect().isSelected()) {
					if(!user.hs.containsValue(i.getCourseName())&&!haset.contains(i.getCourseName())) {
						if(!user.getTimeList().contains(new time(i.getTime(),i.getDays()).getS())&&!time.contains(new time(i.getTime(),i.getDays()).getS())) {
							
							haset.add(i.getCourseName());
							time.add(new time(i.getTime(),i.getDays()).getS());
							System.out.println(time.toString());
							
						}
							
						else {
							error=true;
							errorMsg.setText("Action fail!\n"+ "Time conflict!");
							time.remove(new time(i.getTime(),i.getDays()).getS());
							break;
						}
							
						
						
					}
						
					else {
						error=true;
						haset.remove(i.getCourseName());
						errorMsg.setText("Action fail \n"+"You have duplicated class!");
						break;
					}
					}	
			}
			if(error==false)
				for(course i:data) {
					if(i.getSelect().isSelected()) {
						ps.setString(1,i.getCRN());
						ps.setString(2, i.getCourseName());
						ps.setString(3, i.getCourseSection());
						ps.setInt(4, user.userId);
						ps.setString(5, i.getTime());
						ps.setString(6, i.getDays());
						
						user.hs.put(i.getCRN(),i.getCourseName());
						user.timeList.add(new time(i.getTime(),i.getDays()).getS());
						
						if(i.getAct()+1==i.getCap()) {
							ps4.setString(1, "close");
							ps4.setString(2, i.getCRN());
							i.setStatus("close");
							ps4.execute();
							i.getSelect().setDisable(true);
						}
						i.setAct(i.getAct()+1);
						classTable.getItems().set(classTable.getItems().indexOf(i),i);
						ps.execute();
						ps2.setString(1, i.getCRN());
						ps2.execute();
						errorMsg.setText("Complete");
						
				}
			}		
				for(course j:data) {
					j.getSelect().setSelected(false);
						
				}
			
			
			textBox.setText(user.hs.values().toString());
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		
	}
	
	
	
	public void goBack(ActionEvent event ) throws IOException {
		((Node)event.getSource()).getScene().getWindow().hide();
		Parent tableViewParent = FXMLLoader.load(getClass().getResource("studentView.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(tableViewScene);
        window.show();
        System.out.println(user.hs.values().toString());
		
	}
	
	
	

}
