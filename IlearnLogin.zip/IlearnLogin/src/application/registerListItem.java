package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.scene.control.CheckBox;

public class registerListItem {
	SimpleStringProperty CRN;
	SimpleStringProperty courseName;
	SimpleStringProperty courseSection;
	 int rowNumber;
	 SimpleStringProperty time;
	 SimpleStringProperty day;
	CheckBox select;
	
	
	public void setTime(String time) {
		this.time.set(time);
		
		
	}
	public String getTime() {
		return time.get();
		
		
	}
	public String getDay() {
		return day.get();
		
	}
	
	public void setDay(String day) {
		this.day.set(day);
		
		
	}
	
	
	public CheckBox getSelect() {
		return select;
	}
	public void setSelect(CheckBox select) {
		this.select = select;
	}
	
	public registerListItem(String CRN,String courseName,String time,String day,String courseSection,int rowNumber){
		this.CRN= new SimpleStringProperty(CRN);
		this.courseName = new SimpleStringProperty(courseName);
		this.courseSection= new SimpleStringProperty(courseSection);
		this.select=new CheckBox();
		this.rowNumber=rowNumber;
		this.time = new SimpleStringProperty(time);
		this.day = new SimpleStringProperty(day);
		
		
	}
	public int getRowNumber() {
		return rowNumber;
	}
	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}
	public  String getCRN() {
		return CRN.get();
	}
	public  void setCRN(String cRN) {
		this.CRN.set(cRN);;
	}
	public String getCourseName() {
		return courseName.get();
	}
	public  void setCourseName(String courseName) {
		this.courseName.set(courseName);;
	}
	public  String getCourseSection() {
		return courseSection.get();
	}
	public  void setCourseSection(String courseSection) {
		this.courseSection.set(courseSection);;
	}
	
	
	
	

}
