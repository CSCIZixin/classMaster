package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ResourceBundle;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.AccessibleRole;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class scheduleViewController implements Initializable{
	@FXML GridPane gridPane;
	final static int M =1,T=2,W=3,R=4,F=5,eight=1,night=2,ten=3,eleven=4,twelve=5; 
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			String query = ("SELECT * FROM register where StudentId="+ user.userId);
			Connection con = DBConnect.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			ArrayList<Label> list = new ArrayList<Label>();
			
			while(rs.next()) {
				String time=rs.getString("time");
				String day = rs.getString("day");
				String name = rs.getString("coursename");
				if(time.contains("08")) {
					if(day.equals("MWF")) {
						gridPane.add(AlignLabel(AlignLabel(new Label(name))),M,eight);
						gridPane.add(AlignLabel(new Label(name)),W,eight);
						gridPane.add(AlignLabel(new Label(name)),F,eight);
						
					}
					if(day.contains("TR")) {
						gridPane.add(AlignLabel(new Label(name)),T,eight);
						gridPane.add(AlignLabel(new Label(name)),R,eight);
					}
											
				}
				
				if(time.contains("09")) {
					if(day.equals("MWF")) {
						gridPane.add(AlignLabel(new Label(name)),M,night);
						gridPane.add(AlignLabel(new Label(name)),W,night);
						gridPane.add(AlignLabel(new Label(name)),F,night);
						
					}
					if(day.contains("TR")) {
						gridPane.add(AlignLabel(new Label(name)),T,night);
						gridPane.add(AlignLabel(new Label(name)),R,night);
						
						
					}
						
						
				}
				if(time.contains("10")) {
					if(day.equals("MWF")) {
						gridPane.add(AlignLabel(new Label(name)),M,ten);
						gridPane.add(AlignLabel(new Label(name)),W,ten);
						gridPane.add(AlignLabel(new Label(name)),F,ten);
						
					}
					if(day.contains("TR")) {
						gridPane.add(AlignLabel(new Label(name)),T,ten);
						gridPane.add(AlignLabel(new Label(name)),R,ten);
						
						
					}
						
						
				}
				if(time.contains("11")) {
					if(day.equals("MWF")) {
						gridPane.add(AlignLabel(new Label(name)),M,eleven);
						gridPane.add(AlignLabel(new Label(name)),W,eleven);
						gridPane.add(AlignLabel(new Label(name)),F,eleven);
						
					}
					if(day.contains("TR")) {
						gridPane.add(AlignLabel(new Label(name)),T,eleven);
						gridPane.add(AlignLabel(new Label(name)),R,eleven);
						
						
					}
						
						
				}
				
				if(time.contains("12")) {
					if(day.equals("MWF")) {
						gridPane.add(AlignLabel(new Label(name)),M,twelve);
						gridPane.add(AlignLabel(new Label(name)),W,twelve);
						gridPane.add(AlignLabel(new Label(name)),F,twelve);
						
					}
					if(day.contains("TR")) {
						gridPane.add(AlignLabel(new Label(name)),T,twelve);
						gridPane.add(AlignLabel(new Label(name)),R,twelve);
						
					}
								
				}				
			}
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		gridPane.getChildren();
		
	}
	
	public Label AlignLabel(Label la) {
		
		la.setText("   "+la.getText());;
		return la;
	}
	
	public void backButtonClicked(ActionEvent event) throws IOException {
		
		((Node)event.getSource()).getScene().getWindow().hide();
		 
        
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("studentView.fxml"));
        Parent tableViewParent = loader.load();
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(tableViewScene);
        window.show();
		
		
	}
	

}
