package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class studentViewController implements Initializable{
	
	@FXML TableView<registerListItem> tableView;
	@FXML TableColumn col1,col2,col3,col5,timeCol,dayCol;
	@FXML Button addBtn;
	
	ObservableList<registerListItem> data = FXCollections.observableArrayList() ;

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		
		try {
			String query = ("SELECT * FROM register where StudentId="+ user.userId);
			Connection con = DBConnect.getConnection();
			Statement stmt = con.createStatement();

	        ResultSet rs = stmt.executeQuery(query);
	       
	        col1.setCellValueFactory(
	                new PropertyValueFactory<registerListItem, String>("CRN"));
	        col2.setCellValueFactory(
	                new PropertyValueFactory<registerListItem, String>("courseName"));
	        col3.setCellValueFactory(
	                new PropertyValueFactory<registerListItem, String>("courseSection"));   
	        col5.setCellValueFactory(
	                new PropertyValueFactory<registerListItem, String>("select"));
	        timeCol.setCellValueFactory(
	                new PropertyValueFactory<registerListItem, String>("time"));
	        dayCol.setCellValueFactory(
	                new PropertyValueFactory<registerListItem, String>("day"));

	        while (rs.next()) {
	        	
	           String item1 = rs.getString("CRN"); 
	           String item2 = rs.getString("coursename");
	           String item3 = rs.getString("courseSection");
	           int item4 = rs.getInt("rowNumber");
	           String time = rs.getString("time");
	           String day = rs.getString("day");
	           System.out.println(time);
	           data.add(new registerListItem(item1,item2,time,day,item3,item4));
	           
	       
	        }
	     
	        tableView.setItems(data);
	        
	        
		}catch(Exception s) {
			
		}
		
	}
	public void Remove(ActionEvent event) throws SQLException {
		java.sql.PreparedStatement ps1;
		java.sql.PreparedStatement ps2,ps3,ps4,ps5;
		Connection conn = DBConnect.getConnection();
		ps1 = conn.prepareStatement("Delete From `register` where rowNumber= ?");
		ps3 = conn.prepareStatement("UPDATE `course` SET `act`= act-1 WHERE CRN=?");
		ps4 = conn.prepareStatement("UPDATE `course` SET status = ? WHERE CRN=?");
		ps5 = conn.prepareStatement("SELECT * FROM course WHERE CRN=?");
		
		
		ObservableList<registerListItem> selectedRows, allPeople;
		selectedRows=FXCollections.observableArrayList();
        allPeople = tableView.getItems();
        
        for(registerListItem item: data) {
        	if(item.select.isSelected()) {
        		
        		selectedRows.add(item);
        		ps1.setInt(1, item.rowNumber);
        		ps1.execute();
        		user.getHs().remove(item.getCRN()); 		
        		ps3.setString(1, item.getCRN());
				ps3.execute();
				ps5.setString(1,item.getCRN());
				ResultSet rs =ps5.executeQuery();
				rs.next();
				user.getTimeList().remove(rs.getString("time")+rs.getString("day"));
		
				if(rs.getString("status").equals("close")) {
					ps4.setString(1, "open");
					ps4.setString(2, item.getCRN());
					ps4.execute();
				}
					
					

        	}
        }
        
        //loop over the selected rows and remove the Person objects from the table
        for (registerListItem item : selectedRows)
        {		
            data.remove(item);
        }	
		
	}
	
	
	public void add(ActionEvent event)throws IOException {
		((Node)event.getSource()).getScene().getWindow().hide();
		 
	        
	        
	        
	        FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(getClass().getResource("classView.fxml"));
	        Parent tableViewParent = loader.load();
	        Scene tableViewScene = new Scene(tableViewParent);
	        
	        classViewController controller = loader.getController();
	        controller.textBox.setText(user.hs.values().toString());;
	        controller.setdisable();   
	        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
	        
	        window.setScene(tableViewScene);
	        window.show();
	        System.out.println(user.hs);
		
	}
	public void selectSubject(ActionEvent event)throws IOException {
		((Node)event.getSource()).getScene().getWindow().hide();
		 
	        
	        FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(getClass().getResource("classView.fxml"));
	        Parent tableViewParent = loader.load();
	        Scene tableViewScene = new Scene(tableViewParent);
	        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
	        
	        window.setScene(tableViewScene);
	        window.show();
	
		
	}
	
	public void scheduleButtonClicked(ActionEvent event) throws IOException {
		((Node)event.getSource()).getScene().getWindow().hide();
		 
        
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("scheduleView.fxml"));
        Parent tableViewParent = loader.load();
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(tableViewScene);
        window.show();
		
		
		
		
	}
	
	public void logOut(ActionEvent event) throws IOException {
			
			((Node)event.getSource()).getScene().getWindow().hide();
		
		 	Parent tableViewParent = FXMLLoader.load(getClass().getResource("LoginMain.fxml"));
	        Scene tableViewScene = new Scene(tableViewParent);
	        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
	        
	        window.setScene(tableViewScene);
	        window.show();
		
	}
	
	

}
