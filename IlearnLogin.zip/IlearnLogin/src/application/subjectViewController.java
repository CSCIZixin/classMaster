package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.stage.Stage;

public class subjectViewController implements Initializable {
	@FXML ListView list;
	@FXML Button confirm;
	public static String class_name;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		list.getItems().addAll("Computer Science","English","Mathematics");
		
		
		
	}
	
	
	public void confirmButtonPushed(ActionEvent event) throws IOException {
		((Node)event.getSource()).getScene().getWindow().hide();
		ObservableList listOfItems = list.getSelectionModel().getSelectedItems();
       
       for (Object item : listOfItems)
       {
           class_name=(String) item;
       }
		   
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("classView.fxml"));
        Parent tableViewParent = loader.load();
        Scene tableViewScene = new Scene(tableViewParent);
        
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.show();
        	
	}
	
	
	
	public void goBackButtonPushed(ActionEvent event) throws IOException{
		((Node)event.getSource()).getScene().getWindow().hide();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("studentView.fxml"));
        Parent tableViewParent = loader.load();
        Scene tableViewScene = new Scene(tableViewParent);
        
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.show();
		
	}

}
