package application;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.control.CheckBox;
import javafx.scene.text.Text;

public class course {
	SimpleStringProperty CRN;
	SimpleStringProperty courseName;
	SimpleStringProperty courseSection;
	SimpleStringProperty teacher;
	SimpleIntegerProperty cap;
	SimpleIntegerProperty act;
	SimpleStringProperty time;
	SimpleStringProperty status;
	SimpleStringProperty days;
	CheckBox select;
	Text text;
	public Text getText() {
		return text;
	}
	public void setText(Text text) {
		this.text = text;
	}
	public String getStatus() {
		return status.get();
	}
	public void setStatus(String status) {
		this.status.set( status);
	}
	public int getCap() {
		return cap.get();
	}
	public void setCap(int cap) {
		this.cap .set( cap);
	}
	public int getAct() {
		return act.get();
	}
	public void setAct(int act) {
		this.act .set(act);;
	}
	
	
	
	public CheckBox getSelect() {
		return select;
	}
	public void setSelect(CheckBox select) {
		this.select = select;
	}
	public course(String cRN, String courseName, String courseSection,String time,String days,int cap,int act, String teacher,String status ) {
		super();
		CRN = new SimpleStringProperty (cRN);
		this.courseName = new SimpleStringProperty (courseName);
		this.courseSection = new SimpleStringProperty (courseSection);
		this.teacher = new SimpleStringProperty (teacher);
		this.cap= new SimpleIntegerProperty(cap);
		this.act = new SimpleIntegerProperty(act);
		this.select=new CheckBox();
		this.time = new SimpleStringProperty(time);
		this.status =  new SimpleStringProperty(status);
		this.days = new SimpleStringProperty(days);
		this.text= new Text("hello");
		
		
	}
	
	
	public String getDays() {
		return days.get();
	}
	public void setDays(String days) {
		this.days.set(days);
		
	}
	
	
	public String getCRN() {
		return CRN.get();
	}
	public void setCRN(String cRN) {
		CRN .set(cRN);;
	}
	public String getCourseName() {
		return courseName.get();
	}
	public void setCourseName(String courseName) {
		this.courseName .set(courseName);;
	}
	public String getCourseSection() {
		return courseSection.get();
	}
	public void setCourseSection(String courseSection) {
		this.courseSection.set(courseSection);;
	}
	public String getTeacher() {
		return teacher.get();
	}
	public void setTeacher(String teacher) {
		this.teacher.set(teacher);;
	}
	public String getTime() {
		return time.get();
	}
	public void setTime(String time) {
		this.time .set(time);;
	}

}
