package application;

import java.util.Comparator;
import java.util.HashSet;
import application.user.time;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.Vector;

public class test implements Comparable<test>{
	String a;
	String b ;
	time t ;

	test (time t){
		
		this.t = t;
		
		
	}
	
public static void main(String[] args) {
	
	HashSet<time> time =new HashSet<time>();
	time a =new time("a","s");
	time b =new time("a","s");
	time c =a;
	HashSet<String> h= new HashSet<String>();
	h.add(new String("s"));
	h.add(new String("sk"));
	
	test t1= new test(a);
	
	test t2= new test(b);
	
	
	System.out.println(h.contains(a));
	System.out.println(h.toString());
}

@Override
public int compareTo(test o) {
	
	if(this.t.toString().compareTo(o.toString().toString())==1)
		return 1;
	else return 0;
}





}
